import React, { useEffect, useState, useCallback } from 'react';
import { toast } from "react-toastify";
import axios from "axios";
import { useAtomValue } from "jotai";
import { loginIdState } from "../../utils/jotai";

export default function DailyQuest({ setTab }) {
    const loginId = useAtomValue(loginIdState);
    const [quests, setQuests] = useState([]);
    
    // ★ [추가] 남은 시간 상태
    const [timeLeft, setTimeLeft] = useState("");

    // 1. 자정까지 남은 시간 계산 함수
    const calculateTimeLeft = useCallback(() => {
        const now = new Date();
        const midnight = new Date();
        
        // 다음 날 00:00:00 설정
        midnight.setHours(24, 0, 0, 0); 
        
        const diff = midnight - now; // 밀리초 차이

        // 시, 분, 초 계산
        const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
        const minutes = Math.floor((diff / 1000 / 60) % 60);
        const seconds = Math.floor((diff / 1000) % 60);

        // 00:00:00 포맷 만들기
        const h = String(hours).padStart(2, "0");
        const m = String(minutes).padStart(2, "0");
        const s = String(seconds).padStart(2, "0");

        return `${h}:${m}:${s}`;
    }, []);

    // 2. 1초마다 타이머 갱신 (useEffect)
    useEffect(() => {
        // 처음 마운트 될 때 즉시 계산
        setTimeLeft(calculateTimeLeft());

        const timer = setInterval(() => {
            setTimeLeft(calculateTimeLeft());
        }, 1000);

        // 언마운트 시 타이머 해제 (메모리 누수 방지)
        return () => clearInterval(timer);
    }, [calculateTimeLeft]);

    // ---------------------------------------------------------
    // (기존 loadQuests, handleQuestClick, handleClaim 코드는 그대로 유지...)
    // ---------------------------------------------------------

    const loadQuests = useCallback(async () => {
        if (!loginId) return;
        try {
            const resp = await axios.get("/point/quest/list");
            setQuests(resp.data);
        } catch (e) { console.error("퀘스트 로드 실패", e); }
    }, [loginId]);

    useEffect(() => { loadQuests(); }, [loadQuests]);

    const handleQuestClick = async (quest) => {
        if (quest.done) return;
        if (quest.action === "roulette") {
            setTab("roulette");
            toast.info("🎰 룰렛 탭으로 이동합니다!");
        } else if (quest.action === "quiz") {
            const answer = window.prompt("Q. 'I am your father' 명대사가 나오는 영화는?");
            if (answer && (answer.toLowerCase().includes("스타워즈") || answer.toLowerCase().includes("star wars"))) {
                toast.success("정답입니다! 진행도가 올라갑니다.");
                await axios.post("/point/quest/progress", { type: "QUIZ" });
                loadQuests(); 
            } else {
                toast.error("땡! 다시 시도해보세요. (힌트: 스OO즈)");
            }
        } else {
            toast.info(`'${quest.title}' 페이지로 이동합니다.`);
        }
    };

    const handleClaim = async (type) => {
        try {
            const resp = await axios.post("/point/quest/claim", { type: type });
            if (resp.data.startsWith("success")) {
                const reward = resp.data.split(":")[1];
                toast.success(`보상이 지급되었습니다! +${reward}P 💰`);
                loadQuests(); 
            } else {
                toast.warning(resp.data.split(":")[1]);
            }
        } catch (e) { toast.error("보상 수령 실패"); }
    };

    return (
        <div className="quest-card">
            <div className="d-flex justify-content-between align-items-center mb-3">
                <h5 className="fw-bold text-white mb-0">📜 일일 퀘스트</h5>
                
                {/* ★ [수정] 타이머 적용 부분 */}
                <span className="badge bg-dark border border-secondary text-warning" style={{fontSize:'0.8rem', fontFamily:'monospace'}}>
                    ⏳ Reset {timeLeft}
                </span>
            </div>

            <div className="quest-list">
                {quests.map((q, index) => (
                    <div key={q.type || index} className={`quest-item ${q.done ? 'done-bg' : ''}`}>
                        <div className="d-flex align-items-center">
                            <div className="quest-icon-box me-3">{q.icon}</div>
                            <div className="flex-grow-1">
                                <div className="d-flex justify-content-between align-items-center mb-1">
                                    <span className={`quest-title ${q.done ? 'text-decoration-line-through text-muted' : ''}`}>{q.title}</span>
                                    <span className="quest-reward text-warning fw-bold small">+{q.reward} P</span>
                                </div>
                                <div className="d-flex justify-content-between align-items-end">
                                    <small className="text-secondary me-2" style={{fontSize:'0.8rem'}}>{q.desc}</small>
                                    
                                    {q.claimed ? (
                                        <span className="text-muted small">완료</span>
                                    ) : q.done ? (
                                        <button className="btn btn-xs btn-primary py-0 px-2 fw-bold" style={{fontSize:'0.75rem'}} onClick={() => handleClaim(q.type)}>받기</button>
                                    ) : (
                                        <span className="text-neon-mint small fw-bold">{q.current} / {q.target}</span>
                                    )}
                                </div>
                                <div className="progress mt-2" style={{height: '4px', backgroundColor: '#333'}}>
                                    <div className="progress-bar" style={{width: `${Math.min((q.current / q.target) * 100, 100)}%`, backgroundColor: q.done ? '#00d2d3' : '#e50914'}}></div>
                                </div>
                            </div>
                            {!q.done && (
                                <button className="btn btn-link text-secondary p-0 ms-2" onClick={() => handleQuestClick(q)} title="바로가기">🚀</button>
                            )}
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}