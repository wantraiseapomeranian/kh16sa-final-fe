
export default function NeedPermission() {
    return(<>
        <h1>접근 금지</h1>
        <h2>해당 기능을 이용하기 위해 필요한 권한이 부족합니다</h2>
    </>)
}