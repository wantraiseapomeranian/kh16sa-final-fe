

export default function TargetNotfound() {
    return (<>
        <h1>페이지가 존재하지 않습니다</h1>
        <h2>주소가 맞는지 확인 후 다시 이용해주세요</h2>
    </>)
}